# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#--------------------------------------------------------------------------
# Ex. 9
import requests as rq
r9 = rq.get(BASE_URL, timeout = TIMEOUT)
print(r9.status_code) # atribut
print(r9.ok) # atribut
print(r9.encoding) # atribut
print(r9.url) # atribur

#---------------------------------------------------------------------------
# Ex. 10
r10 = rq.get(BASE_URL, timeout = TIMEOUT)
r10.raise_for_status()

try:
    r10 = rq.get("https://httpbin.org/status/404", timeout=TIMEOUT)
    # cand am scris BASE_URL + "/this-page-does-not-exist" mereu returna codul 200
    print(r10.status_code)
    r10.raise_for_status()
except rq.HTTPError:
    print("Buna ziua, e greseala HTTP")

#---------------------------------------------------------------------------
# Ex. 11
r11 = rq.get(BASE_URL, timeout = TIMEOUT)
for nume, valoare in r11.headers.items():
    print(f"{nume}: {valoare}")

#----------------------------------------------------------------------------
# Ex. 12
r12 = rq.get(BASE_URL, timeout = TIMEOUT)
print(r12.headers.get("Server", "lipseste"))
print(r12.headers.get("Content-Type","lipseste"))
print(r12.headers.get("content-type"))
# am observat acelasi raspuns deci response.headers nu e case sensitive

#----------------------------------------------------------------------------
# Ex. 13
r13 = rq.get(BASE_URL, timeout = TIMEOUT)
print(r13.text.lower().count("cyber"))
# pot inlantui lower().count() deoarece lower() returneaza str la care
# se poate utiliza metoda count(). Aceasta pereche se foloseste pentru
# ca cuvantul cyber sa fie numarat oricum el va fi scris

#----------------------------------------------------------------------------
#Ex. 14
r14 = rq.get(BASE_URL, timeout = TIMEOUT)
html = r14.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")

titlu = html[start:end].strip()
print(titlu)
#----------------------------------------------------------------------------
# Ex. 15
r15 = rq.get(BASE_URL, timeout = TIMEOUT)
lines = r15.text.splitlines()
print(len(r15.text.splitlines()))
print(max(lines, key=len))

#----------------------------------------------------------------------------
# Ex. 16
r16 = rq.get(BASE_URL, timeout = TIMEOUT)
link = r16.url
if link.startswith("https://"):
    print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")

#-----------------------------------------------------------------------------
# Ex. 17
r17 = rq.get(BASE_URL, timeout = TIMEOUT)
for x in r17.history:
    print(x.status_code, x.url)
print(r17.url)

#-----------------------------------------------------------------------------
# Ex. 18
r18 = rq.get(BASE_URL, timeout = TIMEOUT)
r18a = rq.head(BASE_URL, timeout = TIMEOUT)
print(len(r18.content))
print(len(r18a.content))
# metoda get() transmite tot continutul paginii, in rezultat
# len() returneaza o valoare destul de mare
# pe cand metoda head() returneaza doar antetele raspunsului
# care nu contin "content" de aceea len() returneaza 0.

#-----------------------------------------------------------------------------
# Ex. 19
r19 = rq.get(BASE_URL, timeout = TIMEOUT)
if r19.cookies:
    for i in r19.cookies:
        print(i.name, i.secure)

else:
    print("Niciun cookie setat")

#-----------------------------------------------------------------------------
# Ex. 20
sesie = rq.Session()
sesie.headers.update({
    "User-Agent": "WebLab-Sasha"
})

r20 = sesie.get(ECHO_URL + "/headers", timeout=TIMEOUT)

print(r20.status_code)
print(r20.text)

if r20.ok:
    try:
        print(r20.json())
    except rq.exceptions.JSONDecodeError:
        print("Raspunsul nu este JSON valid")

# .text nu are paranteze deoarece este un atribut si tine valoarea requestului
#json() are paranteze deoarece este o metoda de transmitere a datelor de pe site
#care in python se converteaza in list sau
#-----------------------------------------------------------------------------