# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
print("RULEZ MAIN.PY")
#---------------------------------------------------------------------------
# Ex. 44
import webtools
webtools.get_title(webtools.fetch(BASE_URL).text)
r44 = webtools.fetch(BASE_URL)
print(webtools.get_title(r44.text))
#---------------------------------------------------------------------------
# Ex. 45
from webtools import get_title, security_headers
r45 = webtools.fetch(BASE_URL)
print(get_title(r45.text))
print(security_headers(BASE_URL))

def get_title(html):
    return "Test"

print(get_title(r45.text))
print(webtools.get_title(r45.text))
#dacă în modulul webtools și în fișierul main.py
# există funcții cu același nume, funcția definită local suprascrie numele importat prin
# from webtools import get_title.
# pentru a apela funcția originală din modul, folosim webtools.get_title(),
# deoarece prefixul webtools indică modulul din care dorim funcția.


#---------------------------------------------------------------------------
# Ex. 46

#Condiția if __name__ == "__main__"
# verifică dacă fișierul este rulat direct. Dacă rulam direct webtools conditia se indeplineste
#daca in main IMPORTAM webtools conditia nu se indeplineste

#---------------------------------------------------------------------------
# Ex. 47
print(webtools.DEFAULT_HEADERS)
#---------------------------------------------------------------------------
# Ex. 48
if False:
    import argparse
    import webtools

    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    args = parser.parse_args()

    r = webtools.fetch(args.url)
    print(webtools.get_title(r.text))

# pentru a evita conflict dintre 48 si 49 :|
# ---------------------------------------------------------------------------
# Ex. 49
import csv
from datetime import datetime
import webtools


def save_report(results):
    with open("report.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["path", "status", "checked_at"]
        )
        writer.writeheader()

        for path, status in results.items():
            writer.writerow({
                "path": path,
                "status": status,
                "checked_at": datetime.now().isoformat()
            })


BASE_URL = "https://cybercor.org"
paths = ["/", "/robots.txt", "/sitemap.xml"]

results = webtools.check_paths(BASE_URL, paths)
save_report(results)

#---------------------------------------------------------------------------
# Ex. 50
import webtools

webtools.site_report("https://cybercor.org")
#---------------------------------------------------------------------------
