# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#--------------------------------------------------------------------------
# Ex. 1
import requests
import urllib.request

print(requests.__version__)
# pentru a accesa requests am avut nevoie de pip deoarece aceasta
# este o biblioteca externa, pa cand urllib-ul este o biblioteca inclusa
# direct in Python

#---------------------------------------------------------------------------
# Ex. 2
#v1
r2 = requests.get(BASE_URL, timeout=TIMEOUT)
print(r2.status_code)
# Arată clar din ce bibliotecă provine funcția get()

#v2
from requests import get
r2 = get(BASE_URL, timeout=TIMEOUT)
print(r2.status_code)
# ofera o scriere mai usor citibila si curata pentru get()

#---------------------------------------------------------------------------
# Ex. 3
import requests as rq
r3 = rq.get(BASE_URL, timeout=TIMEOUT)
# Aliasul face codul mai ușor de citit atunci când numele bibliotecii este lung
# sau este utilizat frecvent. Un alias neclar poate face codul mai greu de înțeles.

#----------------------------------------------------------------------------
# Ex. 4
'''r4 = urllib.request.urlopen(BASE_URL, timeout=TIMEOUT)
print(r4.status)

corp = r4.read().decode("utf-8")
print(corp[:200])'''

#----------------------------------------------------------------------------
# Ex. 5
print(dir(requests))
print(type(rq.ConnectTimeout))
print(type(rq.__all__))
print(type(rq._types))
# Deci am verificat ca:
# 'ConnectTimeout' - type
# '__all__' - tuple
# 'types' - module

#----------------------------------------------------------------------------
#Ex. 6
help(rq.get)
r6 = rq.get(BASE_URL, timeout = 10)

#----------------------------------------------------------------------------
# Ex. 7
import time
pana = time.perf_counter()
r7 = rq.get(BASE_URL, timeout = TIMEOUT)
dupa = time.perf_counter()
t = r7.elapsed
print(f"diferenta dintre rezultate e {t}\n")

#----------------------------------------------------------------------------
# Ex. 8
try:
    import bs4
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# modulul este un fisier de cod ce contine diferite clase, functii etc.
# un pachet contine mai multe module in sine
# o librarie este o constructie complexa de pachete adaptate sub anumite misiuni.

#-----------------------------------------------------------------------------



