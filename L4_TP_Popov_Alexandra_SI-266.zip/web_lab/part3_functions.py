# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests as rq
import time

#--------------------------------------------------------------------------
# Ex. 21
def fetch(url):
    r = rq.get(url, timeout = TIMEOUT)
    return r
r21 = fetch(BASE_URL)
print(r21.status_code)
#---------------------------------------------------------------------------
# Ex. 22
def get_status(url):
    r = rq.get(url, timeout = TIMEOUT)
    return r.status_code
print(get_status(BASE_URL + "/"))
time.sleep(1)

print(get_status(BASE_URL + "/robots.txt"))
time.sleep(1)

print(get_status(BASE_URL + "/sitemap.xml"))

#---------------------------------------------------------------------------
# Ex. 23
def fetch(url,timeout = 10):
    r = rq.get(url)
    return r
r23 = fetch(BASE_URL)
r23a = fetch(BASE_URL, timeout = 3)

print(r23.status_code)
print(r23a.status_code)

#----------------------------------------------------------------------------
# Ex. 24
r24 = fetch(BASE_URL)

def get_title(html):
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    titlu = html[start:end].strip()
    return titlu

print(get_title(r24.text))

#----------------------------------------------------------------------------
# Ex. 25
def get_title(html):
    """returnează titlul paginii din codul HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    titlu = html[start:end].strip()
    return titlu

help(get_title)

#----------------------------------------------------------------------------
#Ex. 26
def get_status(url: str) -> int:
    r = rq.get(url, timeout = TIMEOUT)
    return r.status_code
print(get_status(BASE_URL))
#print(get_status(123))
# adnotarile de tip nu stopeaza insusi apelul dar programul returneaza o eroare caci
# tipul nu coincide cu cel asteptat.
#----------------------------------------------------------------------------
# Ex. 27
def page_exists(url: str) -> bool:
    try:
        r = rq.get(url, timeout = TIMEOUT)
        r.raise_for_status()
        return True
    except rq.RequestException:
        return False
print(page_exists("https://this-domain-does-not-exist.invalid"))
print(page_exists(BASE_URL))
#----------------------------------------------------------------------------
# Ex. 28
def check_paths(base, paths):
    result = {}

    for path in paths:
        r = rq.get(base + path, timeout=10)
        result[path] = r.status_code

    return result


paths = ["/", "/robots.txt", "/sitemap.xml"]
print(check_paths(BASE_URL, paths))
#-----------------------------------------------------------------------------
# Ex. 29
def get_header(url, name, default="lipsește"):
    r = rq.get(url, timeout = TIMEOUT)
    return r.headers.get(name, default)

print(get_header(BASE_URL, name="Server"))

#-----------------------------------------------------------------------------
# Ex. 30
def security_headers(url):
    r = rq.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    result = {}

    for header in headers:
        result[header] = header in r.headers

    return result

print(security_headers(BASE_URL))


#-----------------------------------------------------------------------------
# Ex. 31
def score_headers(results):
    score = sum(results.values())
    total = len(results)
    return str(score) + "/" + str(total)


print(score_headers(security_headers(BASE_URL)))


#-----------------------------------------------------------------------------
# Ex. 32
def fetch_robots(base):
    url = base.rstrip("/") + "/robots.txt"
    r = rq.get(url, timeout=10)

    if r.status_code == 404:
        return None

    r.raise_for_status()
    return r.text


def disallowed_paths(robots_text):
    paths = []

    if robots_text is None:
        return paths

    for line in robots_text.splitlines():
        line = line.strip()

        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            if path:
                paths.append(path)

    return paths


robots = fetch_robots(BASE_URL)
print(disallowed_paths(robots))


#-----------------------------------------------------------------------------
# Ex. 33
def response_times(*urls):
    results = {}

    for url in urls:
        start = time.perf_counter()
        response = rq.get(url, timeout = TIMEOUT)
        end = time.perf_counter()

        results[url] = end - start

    return results
if __name__ == "__main__":
    print(response_times(BASE_URL, ECHO_URL))
#-----------------------------------------------------------------------------
# Ex. 34

def log(message, **details):
    print(message, end="")

    for key, value in details.items():
        print(f" | {key}={value}", end="")

    print()
log("verificat", url=BASE_URL, status=200)
#print afiseaza rezultate la ecran
#return intoarce valori pentru ca sa le putem stoca in variabile
#-----------------------------------------------------------------------------
