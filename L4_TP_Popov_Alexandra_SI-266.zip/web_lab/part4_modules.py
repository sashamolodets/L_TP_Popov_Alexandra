# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests
import urllib.parse
import re
import hashlib
import json
import socket
import ssl
import _json
import time
#-----------------------------------------------------------------------------
# Ex. 35
def parse_url(url):
    result = urllib.parse.urlparse(url)

    print("Scheme:", result.scheme)
    print("Netloc:", result.netloc)
    print("Path:", result.path)
    print("Query:", result.query)
    print("Fragment:", result.fragment)


parse_url("https://cybercor.org/path?x=1#top")

#-----------------------------------------------------------------------------
# Ex. 36
from urllib.parse import urljoin
def build_urls():
    paths = ["/about", "contact.html", "../index.html"]

    for path in paths:
        print(urljoin(BASE_URL, path))

build_urls()
#-----------------------------------------------------------------------------
# Ex. 37
import re
r37 = requests.get(BASE_URL, timeout = TIMEOUT)
def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    unique_links = list(dict.fromkeys(links))
    return unique_links
print(extract_links(r37.text))
#-----------------------------------------------------------------------------
# Ex. 38
from urllib.parse import urljoin, urlparse

def split_links(links, domain):
    internal = []
    external = []

    for link in links:
        full_url = urljoin(domain, link)
        hostname = urlparse(full_url).netloc

        if hostname == urlparse(domain).netloc:
            internal.append(full_url)
        else:
            external.append(full_url)

    return internal, external
r38 = requests.get(BASE_URL, timeout=TIMEOUT)
links = extract_links(r38.text)

internal, external = split_links(links, BASE_URL)

print("Internal:", internal)
print("External:", external)

#-----------------------------------------------------------------------------
# Ex. 39
from html.parser import HTMLParser
from urllib.parse import urljoin
from html.parser import HTMLParser

class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


# Test
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)

assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp",
], "Parserul nu a găsit exact imaginile așteptate"

print("Testul a trecut!")


# Test pe site-ul real
r39 = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(r39.text)

print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)

print("Taguri img în HTML:", r39.text.lower().count("<img"))

#-----------------------------------------------------------------------------
# Ex. 40
import hashlib

def page_fingerprint(url):
    r40 = requests.get(url, timeout=TIMEOUT)
    r40.raise_for_status()
    return hashlib.sha256(r40.content).hexdigest()
print(page_fingerprint(BASE_URL))
h1 = page_fingerprint(BASE_URL)
h2 = page_fingerprint(BASE_URL)

print(h1 == h2)
#hashurile ar fi diferite cand siteul isi modifica continutul
#-----------------------------------------------------------------------------
# Ex. 41
def save_headers():
    r41 = requests.get(BASE_URL, timeout=TIMEOUT)

    with open("headers.json", "w", encoding="utf-8") as file:
        json.dump(dict(r41.headers), file, indent=2)

    with open("headers.json", "r", encoding="utf-8") as file:
        headers = json.load(file)

    print(headers.get("Content-Type"))


save_headers()

#-----------------------------------------------------------------------------
# Ex. 42
def resolve(hostname):
    return socket.gethostbyname(hostname)

print(resolve("cybercor.org"))
#-----------------------------------------------------------------------------
# Ex. 43

def cert_days_left(hostname):
    context = ssl.create_default_context()

    with socket.create_connection(
        (hostname, 443), timeout=TIMEOUT
    ) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()

    expiry = ssl.cert_time_to_seconds(cert["notAfter"])
    days = (expiry - time.time()) / 86400

    return int(days)



print(cert_days_left("cybercor.org"))
#etoda handle_starttag() este apelată automat de către metoda feed()
#a clasei HTMLParser, atunci când aceasta întâlnește un tag HTML de început.
#-----------------------------------------------------------------------------