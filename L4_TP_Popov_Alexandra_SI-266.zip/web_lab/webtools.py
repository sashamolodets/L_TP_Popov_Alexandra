# Laborator: funcții, metode și importuri pe web
# Student: <Popov Alexandra>

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests as rq
#------------------------------------------------------------------------------------------------------
#1
def fetch(url):
    r = rq.get(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    return r

#------------------------------------------------------------------------------------------------------
#2
def get_status(url):
    r = rq.get(url, timeout = TIMEOUT)
    return r.status_code

#------------------------------------------------------------------------------------------------------
#3
def get_title(html):
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    titlu = html[start:end].strip()
    return titlu

#------------------------------------------------------------------------------------------------------
#4
def security_headers(url):
    r = rq.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    result = {}

    for header in headers:
        result[header] = header in r.headers

    return result

#--------------------------------------------------------------------------------------------------------
#46
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
#47
DEFAULT_HEADERS = {"User-Agent": "WebLab-<popov alexandra>"}

#pentru evitarea conflictului dintre fisiere adaug functia din part3_functions
def check_paths(base, paths):
    result = {}

    for path in paths:
        r = rq.get(base + path, timeout=10)
        result[path] = r.status_code

    return result
#--------------------------------------------------------------------------------------------------------------


# Exercițiul 50 - Raportul site-ului

import requests as rq
import json
import socket
import ssl
import time
import re
from urllib.parse import urljoin, urlparse

BASE_URL = "https://cybercor.org"
TIMEOUT = 10


# Ex. 21 - 23: Obținerea răspunsului
def fetch(url):
    return rq.get(url, timeout=TIMEOUT)


# Ex. 24 - 25: Titlul paginii
def get_title(html):
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")

    if start < len("<title>") or end == -1:
        return ""

    return html[start:end].strip()


# Ex. 30: Antete de securitate
def security_headers(url):
    r = fetch(url)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    return {header: header in r.headers for header in headers}


# Ex. 31: Scorul antetelor
def score_headers(results):
    return f"{sum(results.values())}/{len(results)}"


# Ex. 32: robots.txt
def fetch_robots(base):
    url = base.rstrip("/") + "/robots.txt"
    r = rq.get(url, timeout=TIMEOUT)

    if r.status_code == 404:
        return None

    r.raise_for_status()
    return r.text


def disallowed_paths(robots_text):
    paths = []

    if robots_text is None:
        return paths

    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()

        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            if path:
                paths.append(path)

    return paths


# Ex. 37: Extragerea linkurilor
def extract_links(html):
    return list(dict.fromkeys(
        re.findall(r'href=["\']([^"\']+)["\']', html)
    ))


# Ex. 38: Separarea linkurilor interne și externe
def split_links(links, domain):
    internal = []
    external = []
    domain_host = urlparse(domain).hostname

    for link in links:
        full_url = urljoin(domain, link)
        parsed = urlparse(full_url)

        if parsed.scheme not in ("http", "https"):
            continue

        if parsed.hostname == domain_host:
            internal.append(full_url)
        else:
            external.append(full_url)

    return internal, external


# Ex. 42: Adresa IP
def resolve(hostname):
    return socket.gethostbyname(hostname)


# Ex. 43: Zilele până la expirarea certificatului
def cert_days_left(hostname):
    context = ssl.create_default_context()

    with socket.create_connection(
        (hostname, 443), timeout=TIMEOUT
    ) as sock:
        with context.wrap_socket(
            sock, server_hostname=hostname
        ) as ssock:
            cert = ssock.getpeercert()

    expiry = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expiry - time.time()) / 86400)


# Ex. 50: Lanțul redirecționărilor
def get_redirects(url):
    parsed = urlparse(url)
    http_url = "http://" + parsed.netloc + (parsed.path or "/")

    try:
        r = rq.get(
            http_url, timeout=TIMEOUT, allow_redirects=True
        )

        redirects = []

        for response in r.history:
            redirects.append({
                "status": response.status_code,
                "url": response.url,
                "location": response.headers.get("Location")
            })

        redirects.append({
            "status": r.status_code,
            "url": r.url,
            "location": None
        })

        return redirects

    except rq.RequestException:
        return []


# Ex. 50
def site_report(url):
    # 1. Codul de stare și URL-ul final
    r = fetch(url)
    status = r.status_code
    final_url = r.url

    # 2. Titlul paginii
    title = get_title(r.text)

    # 3. Adresa IP
    hostname = urlparse(final_url).hostname

    try:
        ip = resolve(hostname)
    except (socket.gaierror, OSError):
        ip = "Indisponibil"

    # 4. Redirecționări pornind de la HTTP
    redirects = get_redirects(url)

    # 5. Scorul antetelor de securitate
    try:
        headers = security_headers(final_url)
        security_score = score_headers(headers)
    except rq.RequestException:
        security_score = "Indisponibil"

    # 6. Zile până la expirarea certificatului
    try:
        days_left = cert_days_left(hostname)
    except (OSError, ssl.SSLError, KeyError, ValueError):
        days_left = None

    # 7. Numărul de linkuri interne și externe
    links = extract_links(r.text)
    internal, external = split_links(links, final_url)

    # 8. Căile interzise din robots.txt
    try:
        robots_text = fetch_robots(final_url)
        forbidden_paths = disallowed_paths(robots_text)
    except rq.RequestException:
        forbidden_paths = []

    # Raportul
    report = {
        "url": url,
        "status": status,
        "final_url": final_url,
        "title": title,
        "ip": ip,
        "redirects": redirects,
        "security_score": security_score,
        "certificate_days_left": days_left,
        "internal_links": len(internal),
        "external_links": len(external),
        "forbidden_paths": forbidden_paths
    }

    # Afișarea raportului
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:       {status}")
    print(f"URL final:          {final_url}")
    print(f"Titlu:              {title}")
    print(f"Adresă IP:          {ip}")
    print("Redirecționări:")

    for redirect in redirects:
        print(
            f"  {redirect['status']} -> "
            f"{redirect['location'] or redirect['url']}"
        )

    print(f"Scor securitate:    {security_score}")
    print(f"Certificat:         {days_left} zile rămase")
    print(f"Legături:           {len(internal)} interne, "
          f"{len(external)} externe")
    print(f"Căi interzise:      {', '.join(forbidden_paths) or 'Niciuna'}")

    # Salvarea în JSON
    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=4, ensure_ascii=False)

    print("Salvat în report.json")
    return report









